package com.java.selfdeveloped.spring.crud.k8s.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootCrudK8sAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
