package com.java.selfdeveloped.spring.crud.k8s.configmap.secretapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.java.selfdeveloped.spring.crud.k8s.configmap.secretapi.entity.Order;

public interface OrderRepository extends JpaRepository<Order, Integer> {
}